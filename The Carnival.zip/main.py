

def the_carnival_intro():
    print ("========'The Carnival'=======")
    print ("You wake up and you do not remember anything.")
    print ("You sit up and find yourself in a seemingly empty and derelict carnival at dusk.")
    print ("You look around and can't find any sign of an exit.")
    print ("To your right you see a huge carousel, an assortment of games booths, and a Ferris wheel looming in the distance.")
    print ("To your left you see a House of Mirrors, a Tilt-A-Whirl, and the distant gleaming rails of a massive roller coaster.")
    print ("You have to find a way out. Do you go right toward the Ferris wheel (1) or left toward the roller coaster (2)? ")

    choice = input("Type 1 for right or 2 for left:")

    if choice == "1":
        print ('\n' * 5)
        print ("======== You chose right: toward the Ferris wheel ========")
        print ("As you start down the midway toward the Ferris wheel, you peer into the booths hoping to see another human being. That's when you notice something unusual.")
        print ("Nestled between two games booths is a small wood and glass display case.")
        print ("As you approach to investigate, the display case lights up and weird classical music blares out of old fashioned speakers.")
        print ("The box contains the torso and head of a dummy fortunate teller.")
        print ("His face is cracked and chipped and he wears what once must have been a beautiful and elaborate turban.")
        print ("As you gaze at the fortunate teller a thick parchment card emerges from a narrow slot you didn't notice before.")
        print ("As soon as you take the card, the lights in the box go out and the music stops.")
        print ("In the growing darkness you can barely make out the thick calligraphy strokes on the card.")
        print ("You contemplate the message for a moment before tucking it in your pocket and continuing down the midway.")
        print ("Suddenly you hear angry voices behind you. You catch snippets of what they're saying and realize that these are not people you want to meet.")
        print ("You look for a place to hide.")
        print ("The carousel and the entrance to something called The Enchanted Forest are close-by.")
        
        
        right_to_Ferris()
        

        


   
    elif choice == "2":
        
        print ('\n' * 5)
        print ("======== You chose left: toward the roller coaster ========")
        print ("You walk down the midway, the Tilt-A-Whirl casting a crazy shadow across your path.")
        print ("Suddenly you hear loud, angry voices behind you. Your instinct tells you to hide.")
        print ("You look around and see the House of Mirrors and the entrance to the Haunted Mansion.")
        print ("The voices are getting closer. You have to decide quickly.")
        
        
        scary_houses()
        
        
    else:
                            print ("Invalid action.")
                            print ("Type 1 for right or 2 for left:")
                            the_carnival_intro()


def right_to_Ferris():
    print ("You have to make a decision quickly. The voices are getting closer.")
    print ("Do you run for the carousel (3) or for The Enchanted Forest (4)?")
    choice = input ("Type 3 for the carousel or 4 for The Enchanted Forest:")
    if choice == "3":
                            print ('\n' * 5)
                            print ("========== You chose the carousel ===========")
                            print ("You run toward the carousel as fast as you can.")
                            print ("You climb onto the carousel, the old wood creaking underneath you, and crouch behind an ancient-looking lion.")
                            print ("You can hear the voices clearly now.")
                            print ("You listen carefully and realize that they know you are in the carnival.")
                            print ("They're hunting you for sport and have no intention of letting you out alive.")
                            print ("The voices die down and you wait several minutes before you jump down into the tall grass.")
                            print ("You look around carefully hoping to see an exit. ")
                            print ("You look up and spot a bright crescent moon rising in the sky.")
                            print ("You watch the moon intently for a few moments before examining your surroundings more carefully.")
                            print ("And then you see it.")
                            print ("A ghostly, glinting moon reflected in an antique mirror hanging on the side of an empty booth directly ahead.")
                            print ("Remembering your fortune card, you approach it slowly and quietly, anxious that someone might be lurking in the shadows.")
                            print ("You gaze into the mirror with increasing frustration.")
                            print ("You tear your eyes away with impatience.")
                            print ("You are startled to see twin red dots sweeping in an arc across the sky, closely followed by two more red dots.")
                            print ("You realize that the dots are distant tail-lights just as you see head-lights sweeping down the curve of a mountain in the opposite direction. ")
                            print ("You run toward the lights and eventually come to a fence. You climb it and run across a deserted parking lot.")
                            print ("You walk along a narrow two-lane road for a couple of hours.")
                            print ("You keep close to the woods running alongside the road in case the people at the carnival are still looking for you.")
                            print ("Eventually you reach an all night diner. The hostess is nice and lets you use her phone to call for a ride.")
                            print ("She clearly thinks you're some kind of drug addict with your rumpled clothes and nervous glances toward the door.")
                            print ("You order tea and wait in a corner booth for your ride. Slowly you draw the fortune teller's card from your pocket and lay it on the table, reading it once again.")
                            print ("           Your fortune is in the moon,")
                            print ("           A looking glass will tell you soon. ")
                                   
                            print ('\n' * 2)
                            print ("======= Play Again? =======")
                            print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
                            print ("PLAY AGAIN AND FIND OUT!!")
                            the_carnival_intro()
     
    elif choice == "4":

                            print ('\n' * 5)
                            print ("======= You chose The Enchanted Forest ========")
                            print ("You run through the entrance of The Enchanted Forest and crouch behind a huge dusty unicorn.")
                            print ("You can hear the voices clearly now.")
                            print ("You listen carefully and realize that they know you are in the carnival.")
                            print ("They're hunting you for sport and have no intention of letting you out alive.")
                            print ("The voices fade away and you wait several minutes to make sure they're gone.")
                            print ("While you wait, you look around. The darkening room resembles a Disney museum.")
                            print ("The Enchanted Forest is filled with once elegant stuffed woodland animals and mythical creatures.")
                            print ("One grimy wall is dedicated entirely to silver-winged fairies.")
                            print ("You take a deep breath and edge your way outside.")
                            print ("From the elevated entrance to The Enchanted Forest you can see the eerie swimming image of the moon on the side of a booth. ")
                            print ("As you get closer you realize that you're looking at an antique mirror angled upward and catching the moon.")
                            print ("Remembering your fortune card, your breath catches and you hurry forward.")
                            print ("You gaze into the mirror looking for clues. You're growing impatient and tear your eyes away.")
                            print ("That's when you see it.")
                            print ("In the distance you can see car lights climbing the winding roads of a mountain.")
                            print ("You run toward the distance cars and reach a fence.")
                            print ("You climb the fence and cross a deserted parking lot before you reach a narrow two-lane road.")
                            print ("You walk along the road for a couple of hours, sticking close to the woods running along the side in case you're still being hunted.")
                            print ("The trilling shrieks of insects fill your ears as you hurry along.")
                            print ("Finally you reach a 24-hour diner and the hostess lets you use her phone.")
                            print ("You can feel her silently judging you as you call your friend for a ride.")
                            print ("You order a milkshake and sit in a corner booth as you wait for your friend.")
                            print ("Slowly you draw the fortune teller's card from your pocket and lay it on the table, reading it once again.")
                            print ("           Your fortune is in the moon,")
                            print ("           A looking glass will tell you soon. ")
                            
                            print ('\n' * 2)
                            print ("======= Play Again? ======")
                            print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
                            print ("PLAY AGAIN AND FIND OUT!!")
                            the_carnival_intro()
    else:
                            print ("Invalid action.")
                            print ("Choose 3 for the carousel or 4 for The Enchanted Forest:")
                            right_to_Ferris()
                
                
            

def scary_houses():
    print ("Now is not the time to panic.")
    print ("Should you choose the House of Mirrors (5) or the Haunted Mansion (6)?")

    choice = input ("Type 5 to enter the House of Mirrors or 6 to enter the Haunted Mansion.")

    if choice == "5":
        print ('\n' * 5)
        print ("======= You chose the House of Mirrors =======")
        print ("You run into the House of Mirrors.")
        print ("You go around the first corner and then crouch down, straining to hear the voices outside.")
        print ("You listen carefully and realize that they know you are in the carnival.")
        print ("They're hunting you for sport and have no intention of letting you out alive.")
        print ("The voices fade away and you wait several minutes to make sure they're really gone.")
        print ("The mirrors surrounding you are reflecting infinite murky shadows and your own bright, nervous eyes, unusually white in the contrasting darkness.")
        print ("You creep outside into the dark, cool air.")
        print ("You look around for an exit and are met with shadows and derelict rides and booths. No sign of escape here.")
        print ("You edge your way around to the backside of the House of Mirrors.")
        print ("It's darker than the midway. Your eyes sweep across the darkness and spot a rusty chain-link fence.")
        print ("You climb the fence and run a hundred yards or so before you reach a sharp, downward slope.")
        print ("At the bottom of the slope you see a narrow two-lane road.")
        print ("You walk along the road for twenty minutes before you see a gas station.")
        print ("The gas station attendant lets you use his phone to call for a ride.")
        print ("You wait nervously in the corner by the refrigerated drinks.")
        print ("You wonder if anyone will believe you and decide that they probably won't. It's a relatively unlikely story.")
        print ("You devise a cover story. You'll say that you blacked out from the stress of your college midterms and came to your senses at a remote gas station.")
               
               
        print ('\n' * 2)
        print ("======= Play Again? ======")
        print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
        print ("PLAY AGAIN AND FIND OUT!!")
        the_carnival_intro()

    elif choice =="6":
        print ('\n' * 5)
        print ("======== You chose the Haunted Mansion ========")
        print ("You run into the Haunted Mansion and hide behind the front door.")
        print ("You listen carefully and realize that the people outside know you are in the carnival.")
        print ("They're hunting you for sport and have no intention of letting you out alive.")
        print ("The voices fade away and you wait several minutes to make sure they're really gone.")
        print ("You try to open the door, but it's stuck.")
        print ("You pull harder and the door frame groans loudly. Loud enough to draw unwanted attention.")
        print ("You realize that there must be a back exit.")
        print ("You take a deep breath and start groping your way through the narrow passages of the house.")
        print ("You can barely see in the darkness, but you can make out dusty plastic skeletons and molten candles.")
        print ("You're vaguely impressed with an artistically rendered mural of Jack the Ripper visible through a side window.")
        print ("You go deeper into the house and pass a narrow staircase.")
        print ("Suddenly you reach a wall. You start groping for a door.")
        print ("After several, fruitless minutes you begin to panic. Suddenly, your hand brushes against a gas lamp mounted on the wall.")
        print ("As soon as your hand touches it, a section of the wall swings open. You found a hidden passage!")
        print ("You follow the passage for about twenty mintues. It's pitch black and your heart is pounding.")
        print ("Finally, the passage floor begins to slope upward.")
        print ("At the top of the slope is a wooden cellar door. You give it a push and it creaks open.")
        print ("You climb out into the cool night air.")
        print ("Directly in front of you is a rusted chain-link fence.")
        print ("You climb it and run down a slope to a narrow two-lane road.")
        print ("You walk along the road for twenty minutes before you glimpse the flickering lights of a small gas station.")
        print ("The gas station attendant lets you use his phone to call for a ride.")
        print ("While you wait, you borrow the restroom key attached to a small block of wood.")
        print ("You look at your own, stunned reflection in the cracked mirror for several moments. You're surprised to be alive.")
        print ("Then you start to work washing away the dirt and grime- the only evidence of your strange night.") 
        print ('\n' * 2)
        print ("====== Play Again? ======")
        print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
        print ("PLAY AGAIN AND FIND OUT!!")
        the_carnival_intro()    
               

    

    else:
            print ("Invalid action.")
            print ("Type 5 for the House of Mirrors or 6 for the Haunted Mansion:")
            scary_houses()

    def exit():
        print (" Thanks for reading!. Have a nice day!!")

        exit() 



the_carnival_intro()


